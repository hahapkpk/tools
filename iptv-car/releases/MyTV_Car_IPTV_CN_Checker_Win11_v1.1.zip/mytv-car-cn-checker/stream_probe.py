"""Probe actual HLS media bytes via the local network, with time and speed limits."""
from __future__ import annotations

from dataclasses import dataclass
import ipaddress
import re
import time
import urllib.error
import urllib.parse
import urllib.request

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MyTV-CN-Checker/1.0"
SECRET_PARAMS = {"access_token", "token", "auth", "authinfo", "authorization", "password", "passwd", "secret", "signature", "sign", "sig", "apikey", "api_key"}


@dataclass(frozen=True)
class Result:
    success: bool
    reason: str
    latency_s: float = 0.0
    speed_kib_s: float = 0.0
    sample_bytes: int = 0


def safe_url(url: str, ipv6: bool = False) -> bool:
    try:
        parts = urllib.parse.urlsplit(url.strip())
        if parts.scheme not in ("http", "https") or not parts.hostname or parts.username or parts.password:
            return False
        host = parts.hostname.lower()
        if host in {"localhost", "0.0.0.0"} or host.endswith((".local", ".internal", ".localhost")):
            return False
        try:
            ip = ipaddress.ip_address(host)
            if not ip.is_global or (ip.version == 6 and not ipv6):
                return False
        except ValueError:
            pass
        if any(k.lower() in SECRET_PARAMS for k, _ in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)):
            return False
        if parts.path.lower().endswith((".html", ".htm", ".pdf", ".mp4", ".mkv", ".mpd")):
            return False
        return True
    except (ValueError, TypeError):
        return False


def make_opener(ipv6: bool, direct: bool = True):
    class SafeRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if not safe_url(newurl, ipv6):
                raise ValueError("unsafe redirect")
            return super().redirect_request(req, fp, code, msg, headers, newurl)
    handlers = [SafeRedirect()]
    if direct:
        handlers.insert(0, urllib.request.ProxyHandler({}))
    return urllib.request.build_opener(*handlers)


def fetch_bytes(url: str, opener, limit: int, timeout: float, total_deadline: float, use_range=True):
    start = time.monotonic()
    headers={"User-Agent": USER_AGENT, "Accept": "*/*"}
    if use_range: headers["Range"] = f"bytes=0-{limit-1}"
    req=urllib.request.Request(url,headers=headers)
    try:
        resp=opener.open(req,timeout=timeout)
    except urllib.error.HTTPError as err:
        if not use_range or err.code not in (400,416): raise
        resp=opener.open(urllib.request.Request(url,headers={"User-Agent": USER_AGENT,"Accept": "*/*"}),timeout=timeout)
    with resp:
        if resp.status not in (200, 206):
            raise ValueError("HTTP not OK")
        ctype = resp.headers.get("Content-Type", "").lower()
        if "text/html" in ctype or "application/json" in ctype:
            raise ValueError("not media content")
        data = bytearray()
        first = None
        while len(data) < limit:
            if time.monotonic() - start > total_deadline:
                break
            part = resp.read(min(16384, limit - len(data)))
            if not part:
                break
            if first is None:
                first = time.monotonic() - start
            data.extend(part)
    elapsed = max(0.001, time.monotonic() - start)
    return bytes(data), first if first is not None else elapsed, elapsed


def is_video(data: bytes) -> bool:
    if data.startswith((b"FLV", b"\x1a\x45\xdf\xa3")):
        return True
    if len(data) >= 12 and data[4:8] in (b"ftyp", b"styp", b"moof", b"mdat"):
        return True
    if len(data) < 3 * 188:
        return False
    for off in range(min(188, len(data) - 2 * 188)):
        if data[off] == data[off + 188] == data[off + 376] == 0x47:
            return True
    return False


def media_result(data: bytes, first: float, elapsed: float, cfg: dict) -> Result:
    if len(data) < int(cfg.get("min_sample_bytes", 49152)):
        return Result(False, "short_sample", first, len(data) / 1024 / max(elapsed, .001), len(data))
    if not is_video(data):
        return Result(False, "invalid_media", first, 0.0, len(data))
    speed = len(data) / 1024 / max(elapsed, .001)
    if first > float(cfg["max_first_byte_s"]):
        return Result(False, "slow_start", first, speed, len(data))
    if speed < float(cfg["min_speed_kib_s"]):
        return Result(False, "low_speed", first, speed, len(data))
    return Result(True, "verified", first, speed, len(data))


def choose_variant(lines: list[str]) -> str | None:
    options = []
    for i, line in enumerate(lines[:-1]):
        if not line.startswith("#EXT-X-STREAM-INF:") or lines[i + 1].startswith("#"):
            continue
        bw = re.search(r"BANDWIDTH=(\d+)", line)
        res = re.search(r"RESOLUTION=(\d+)x(\d+)", line)
        bitrate = int(bw.group(1)) if bw else 2500000
        width = int(res.group(1)) if res else 1280
        options.append((width > 1920, width < 640, abs(bitrate - 2500000), lines[i + 1]))
    return min(options)[3] if options else None


def segments_in_playlist(lines: list[str]) -> list[str]:
    segments = [l for l in lines if not l.startswith("#")]
    # Live edge often references an unfinished segment; test the previous ones first.
    if len(segments) >= 3:
        return [segments[-2], segments[-3], segments[-1]]
    return list(reversed(segments))


def validate(url: str, cfg: dict) -> Result:
    ipv6 = bool(cfg.get("enable_ipv6", False))
    if not safe_url(url, ipv6):
        return Result(False, "unsafe_or_credential_url")
    opener = make_opener(ipv6, bool(cfg.get("force_direct_media", True)))
    try:
        current = url
        for _ in range(3):
            if not safe_url(current, ipv6):
                return Result(False, "unsafe_child")
            data, first, elapsed = fetch_bytes(current, opener, 170000,
                                               float(cfg["socket_timeout_s"]),
                                               float(cfg["max_total_sample_s"]), use_range=False)
            if not data.lstrip().startswith(b"#EXTM3U"):
                return media_result(data, first, elapsed, cfg)
            lines = [x.strip() for x in data.decode("utf-8-sig", "replace").splitlines() if x.strip()]
            if "#EXT-X-ENDLIST" in lines:
                return Result(False, "not_live")
            variant = choose_variant(lines)
            if variant:
                current = urllib.parse.urljoin(current, variant)
                continue
            if not any(x.startswith("#EXT-X-TARGETDURATION:") for x in lines):
                return Result(False, "invalid_hls")
            fail_reason = "no_segments"
            for rel in segments_in_playlist(lines)[:2]:
                seg = urllib.parse.urljoin(current, rel)
                if not safe_url(seg, ipv6):
                    fail_reason = "unsafe_child"
                    continue
                try:
                    media, latency, duration = fetch_bytes(
                        seg, opener, int(cfg.get("sample_bytes", 262144)),
                        float(cfg["socket_timeout_s"]), float(cfg["max_total_sample_s"])
                    )
                    result = media_result(media, latency, duration, cfg)
                    if result.success:
                        return result
                    fail_reason = result.reason
                except Exception:
                    fail_reason = "segment_fetch_failed"
            return Result(False, fail_reason)
        return Result(False, "nested_hls")
    except urllib.error.HTTPError as ex:
        return Result(False, f"http_{ex.code}")
    except (TimeoutError, OSError):
        return Result(False, "timeout_or_network")
    except Exception:
        return Result(False, "fetch_failed")
