#!/usr/bin/env python3
"""Local (China-network) IPTV source finder, verifier, and GitHub publisher.

Python 3.10+, standard library. GitHub CLI (gh) only required for publishing.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter, defaultdict
import concurrent.futures
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

from stream_probe import USER_AGENT, safe_url, validate, Result

HERE = Path(__file__).resolve().parent
CCTV_FIRST = ("CCTV-1", "CCTV-13")
ATTR = re.compile(r'([\w-]+)="([^"]*)"')


def log(message):
    print(message, flush=True)


def canonical(name):
    text = re.sub(r"[\x00-\x1f]", "", name).strip()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("央视", "CCTV") if re.match(r"^央视\s*\d", text) else text
    match = re.fullmatch(r"(?i)CCTV[\s-]*(5\+|\d{1,2})(?:\s*(?:HD|高清|超清|4K|1080P|720P|标清))?(?:\s*\([^)]{1,30}\))?", text)
    if match:
        return "CCTV-" + str(int(match.group(1))) if match.group(1).isdigit() else "CCTV-5+"
    aliases = {
        "央视新闻": "CCTV-13", "CCTV新闻": "CCTV-13", "中央新闻": "CCTV-13",
        "中央一套": "CCTV-1", "中央综合": "CCTV-1", "中央十三套": "CCTV-13",
        "Guangdong Satellite TV": "广东卫视", "Hunan Satellite TV": "湖南卫视",
        "Zhejiang Satellite TV": "浙江卫视", "Jiangsu Satellite TV": "江苏卫视",
        "Shanghai Dragon TV": "东方卫视", "上海东方卫视": "东方卫视",
    }
    text = re.sub(r"(?:高清|超清|\bHD\b)\s*$", "", text, flags=re.I).strip()
    return aliases.get(text, text)


def parse_playlist(contents: str, ipv6=False):
    """Support standard M3U and common Chinese IPTV TXT (name,url) lists."""
    contents = contents.lstrip("\ufeff")
    lines = contents.splitlines()
    metadata = None
    group = ""
    for raw in lines:
        line = raw.strip()
        if line.startswith("#EXTGRP:"):
            group = line.split(":", 1)[1].strip()
        elif line.startswith("#EXTINF:"):
            parts = line.split(",", 1)
            if len(parts) < 2:
                metadata = None
                continue
            attrs = dict(ATTR.findall(parts[0]))
            metadata = (canonical(parts[-1]), attrs.get("tvg-logo", ""), attrs.get("group-title", group))
        elif metadata and line and not line.startswith("#"):
            if safe_url(line, ipv6):
                yield metadata[0], line, metadata[1]
            metadata = None
        elif line and not line.startswith("#") and "," in line:
            # Typical TXT: 央视一套,http://example...; comma may exist in URL after first one.
            title, url = line.split(",", 1)
            if url.strip().startswith(("http://", "https://")) and safe_url(url.strip(), ipv6):
                yield canonical(title), url.strip(), ""


def fetch_list(source):
    request = urllib.request.Request(source["url"], headers={"User-Agent": USER_AGENT, "Accept": "text/plain,*/*"})
    limit = 7 * 1024 * 1024
    with urllib.request.urlopen(request, timeout=22) as resp:
        raw = resp.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("playlist too large")
    decoded = raw.decode("utf-8-sig", errors="replace")
    if "<html" in decoded[:300].lower():
        raise ValueError("unexpected HTML")
    return decoded


def collect(config):
    priorities = [canonical(x) for x in config["priority_channels"]]
    selected = set(priorities)
    collected = {name: {} for name in priorities}
    reports = []
    enabled = [s for s in config["sources"] if s.get("enabled", True) and (config.get("enable_ipv6", False) or not s.get("ipv6", False))]
    log(f"[1/4] 读取 {len(enabled)} 条公开直播源（上游列表可使用系统代理；视频测速默认为直连）")
    for source in enabled:
        try:
            body = fetch_list(source)
            count = 0
            accepted = 0
            for name, url, logo in parse_playlist(body, config.get("enable_ipv6", False)):
                count += 1
                if name not in selected:
                    continue
                by_source = collected[name].setdefault(source["name"], [])
                if any(existing[0] == url for existing in by_source):
                    continue
                if len(by_source) < int(config.get("max_per_source_channel", 5)):
                    by_source.append((url, logo))
                    accepted += 1
            reports.append({"source": source["name"], "status": "ok", "entries": count, "priority_candidates": accepted})
            log(f"  + {source['name']}: {count} 条原始记录，{accepted} 条重点频道候选")
        except Exception as exc:
            reports.append({"source": source["name"], "status": "failed", "reason": type(exc).__name__})
            log(f"  - {source['name']}: 采集失败 ({type(exc).__name__})，继续其他来源")

    max_candidates = int(config.get("max_candidates_per_channel", 16))
    per_channel = {}
    for name in priorities:
        # Round-robin across sources to avoid a large first source crowding others out.
        grouped = list(collected[name].values())
        urls = []
        seen = set()
        for i in range(max_candidates):
            for g in grouped:
                if i >= len(g):
                    continue
                url, logo = g[i]
                if url in seen:
                    continue
                seen.add(url)
                urls.append((url, logo))
                if len(urls) >= max_candidates:
                    break
            if len(urls) >= max_candidates:
                break
        per_channel[name] = urls
    return per_channel, reports


def check_sources(config, per_channel):
    unique = {}
    for rows in per_channel.values():
        for url, _logo in rows:
            unique[url] = None
    max_workers = min(24, max(1, int(config.get("max_workers", 12))))
    log(f"[2/4] 通过本机网络测速 {len(unique)} 条不同候选线路，{max_workers} 路并发")
    t0 = time.monotonic()
    results = {}
    def probe_item(url):
        try:
            r = validate(url, config)
            if r.success and config.get("double_check_critical", True) and any(url in [u for u, _ in per_channel[c]] for c in CCTV_FIRST):
                # Second request reduces the risk of transient one-off HLS success.
                second = validate(url, config)
                if not second.success:
                    return url, Result(False, "second_check_" + second.reason)
                r = Result(True, "verified_twice", max(r.latency_s, second.latency_s), min(r.speed_kib_s, second.speed_kib_s), min(r.sample_bytes, second.sample_bytes))
            return url, r
        except Exception:
            return url, Result(False, "unexpected_error")

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(probe_item, url) for url in unique]
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            url, result = future.result()
            results[url] = result
            if index % 20 == 0 or index == len(futures):
                passed = sum(x.success for x in results.values())
                log(f"  验证 {index}/{len(futures)}，已通过 {passed}，累计耗时 {time.monotonic()-t0:.0f} 秒")
    return results


def render(config, per_channel, checks):
    priorities = [canonical(x) for x in config["priority_channels"]]
    keep_per_channel = min(6, max(1, int(config.get("keep_per_channel", 3))))
    groups = {}
    retained = []
    for ch in priorities:
        found = []
        for url, logo in per_channel[ch]:
            result = checks.get(url)
            if result and result.success:
                found.append((url, logo, result))
        found.sort(key=lambda entry: (entry[2].latency_s, -entry[2].speed_kib_s))
        groups[ch] = [{"speed_kib_s": round(x.speed_kib_s, 1), "first_byte_s": round(x.latency_s, 2)} for _, _, x in found[:keep_per_channel]]
        for url, logo, result in found[:keep_per_channel]:
            retained.append((ch, url, logo, result))

    lines = ["#EXTM3U", "# Verified from user-operated China network, not from GitHub overseas runner"]
    for name, url, logo, result in retained:
        attrs = 'group-title="常看央视"' if name in CCTV_FIRST else ('group-title="央视频道"' if name.startswith("CCTV-") else 'group-title="常看卫视"')
        if logo and safe_url(logo, config.get("enable_ipv6", False)) and logo.startswith("https://"):
            attrs += ' tvg-logo="' + logo.replace('"', '') + '"'
        lines.extend([f'#EXTINF:-1 {attrs},{name}', url])
    playlist = "\n".join(lines) + "\n"
    notes = []
    for ch in CCTV_FIRST:
        if not groups.get(ch):
            notes.append(f"{ch} 未找到通过国内实测的线路：已阻止自动上传，保留远端上一版")
    minimum = int(config.get("minimum_verified_lines", 3))
    if len(retained) < minimum:
        notes.append(f"通过检测的线路仅 {len(retained)}，低于保护值 {minimum}，阻止上传")
    reasons = Counter(x.reason for x in checks.values() if not x.success)
    report = {
        "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "network": "locally run on user's own computer", "validated_from": "user local network (media direct)",
        "candidate_urls": len(checks), "verified_urls": sum(r.success for r in checks.values()),
        "published_entries": len(retained), "published_channels": len([x for x in groups if groups[x]]),
        "critical": {ch: len(groups.get(ch, [])) for ch in CCTV_FIRST},
        "channels": groups, "rejection_reasons": dict(reasons.most_common()),
        "thresholds": {"min_speed_kib_s": config["min_speed_kib_s"], "max_first_byte_s": config["max_first_byte_s"]},
        "publication_safe": not notes,
        "warnings": notes,
        "disclaimer": "Passing a short media test does not guarantee uninterrupted playback; playback authorization and location restrictions remain with providers."
    }
    return playlist, report


def command(args, input_data=None, check=True):
    p = subprocess.run(args, input=input_data, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if check and p.returncode:
        raise RuntimeError(f"GitHub CLI command failed ({p.returncode}): " + p.stderr.strip()[:350])
    return p


def configure_gh(config):
    gh = shutil.which("gh")
    if not gh:
        raise RuntimeError("未安装 GitHub CLI。请先执行 winget install --id GitHub.cli -e，然后重新运行本程序。")
    status = command([gh, "auth", "status", "-h", "github.com"], check=False)
    if status.returncode:
        log("首次运行：需要用浏览器完成 GitHub CLI 授权（Token 不保存在脚本或公开仓库）")
        subprocess.run([gh, "auth", "login", "-h", "github.com", "-p", "https", "-w"], check=True)
    login = command([gh, "api", "user", "--jq", ".login"]).stdout.strip()
    expected = config["repo"].split("/", 1)[0]
    if login.lower() != expected.lower():
        raise RuntimeError(f"当前 GitHub CLI 登录账号是 {login}，但应为 {expected}，已停止上传。使用 gh auth switch 更换账号。")
    return gh


def gh_upload(gh, repo, branch, path, payload, message):
    target = f"repos/{repo}/contents/{path}"
    current = command([gh, "api", target, "-q", ".sha"], check=False)
    args = {"message": message, "branch": branch, "content": base64.b64encode(payload).decode("ascii")}
    if current.returncode == 0 and current.stdout.strip():
        args["sha"] = current.stdout.strip()
    elif "404" not in current.stderr:
        raise RuntimeError("无法查询远端文件当前版本，未上传：" + current.stderr.strip()[:250])
    # Pass JSON through stdin so no token or large content appears in command arguments.
    result = command([gh, "api", target, "-X", "PUT", "--input", "-"], json.dumps(args, ensure_ascii=False))
    if '"content"' not in result.stdout:
        raise RuntimeError("GitHub 未返回更新成功信息")
    return True


def upload(config, playlist: str, report: dict):
    gh = configure_gh(config)
    repo = config["repo"]
    branch = config.get("branch", "main")
    log("[4/4] 上传至 " + repo + " (仅修改 live-cn.m3u 和 status-cn.json)")
    gh_upload(gh, repo, branch, "iptv-car/live-cn.m3u", playlist.encode("utf-8"), "chore(iptv): publish domestic-network verified car IPTV")
    gh_upload(gh, repo, branch, "iptv-car/status-cn.json", (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"), "chore(iptv): update domestic-network validation report")
    log("上传成功： https://raw.githubusercontent.com/" + repo + "/" + branch + "/iptv-car/live-cn.m3u")


def main(argv=None):
    parser = argparse.ArgumentParser(description="国内网络 IPTV 直播源一键筛选及上传工具")
    parser.add_argument("--config", default=str(HERE / "config.json"))
    parser.add_argument("--no-upload", action="store_true", help="只生成本地文件，不上传 GitHub")
    args = parser.parse_args(argv)
    with open(args.config, "r", encoding="utf-8-sig") as f:
        cfg = json.load(f)
    log("MyTV 车机国内网络直播源筛选器 v1.0")
    log("关注频道：CCTV-1、CCTV-13，其次其他央视和卫视")
    per_channel, sources_report = collect(cfg)
    results = check_sources(cfg, per_channel)
    playlist, status = render(cfg, per_channel, results)
    status["sources"] = sources_report
    output = HERE / "output"
    output.mkdir(exist_ok=True)
    (output / "live-cn.m3u").write_text(playlist, encoding="utf-8")
    (output / "status-cn.json").write_text(json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    log(f"[3/4] 国内实测通过 {status['verified_urls']} 条，精选 {status['published_entries']} 条，覆盖 {status['published_channels']} 个频道")
    log(f"  CCTV-1: {status['critical']['CCTV-1']} 条；CCTV-13: {status['critical']['CCTV-13']} 条")
    if not status["publication_safe"]:
        for reason in status["warnings"]:
            log("  [保护] " + reason)
        log("已保留本地输出/报告，不覆盖现有 GitHub 订阅。")
        return 2
    if args.no_upload:
        log("--no-upload 模式：未上传，文件在 output 目录")
        return 0
    upload(cfg, playlist, status)
    log("完成。车机订阅 live-cn.m3u 地址一次，以后每次运行更新同一地址。")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已取消。")
        sys.exit(130)
    except Exception as exc:
        print("\n[错误] " + str(exc), file=sys.stderr)
        sys.exit(1)
