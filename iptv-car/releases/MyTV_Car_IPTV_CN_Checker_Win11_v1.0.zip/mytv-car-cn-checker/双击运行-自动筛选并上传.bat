@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ================================================
echo    MyTV 国内直播源筛选 + GitHub 自动上传
 echo    CCTV-1 / CCTV-13 优先，其他央视/卫视其次
 echo    验证视频数据：国内网络直连（默认不走代理）
echo ================================================
echo.
where py >nul 2>&1
if %errorlevel% equ 0 (
    py -3 checker.py
) else (
    where python >nul 2>&1
    if %errorlevel% equ 0 (
        python checker.py
    ) else (
        echo [错误] 未找到 Python 3，请先安装 Python 3.10 或以上版本。
        echo 可以在 PowerShell 中运行： winget install -e --id Python.Python.3.13
    )
)
echo.
echo 查看结果：output\live-cn.m3u 和 output\status-cn.json
echo.
pause
