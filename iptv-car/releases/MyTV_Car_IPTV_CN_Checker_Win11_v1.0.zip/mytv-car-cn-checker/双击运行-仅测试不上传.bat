@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (
    py -3 checker.py --no-upload
) else (
    python checker.py --no-upload
)
echo.
pause
